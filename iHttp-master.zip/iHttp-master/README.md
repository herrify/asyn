# iHttp
简介：
    发送HTTP/HTTPS请求的类[支持批量异步GET(POST)请求,支持服务器代理,支持自定义RequestHeader]

Description: 
    You can send HTTP/HTTPS request with this class. It supports batch-asynchronous GET (POST) request, supports server proxy, and supports for custom RequestHeader
