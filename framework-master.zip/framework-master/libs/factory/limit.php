<?php
return new Swoole\Limit(Swoole::$php->config['limit']);
