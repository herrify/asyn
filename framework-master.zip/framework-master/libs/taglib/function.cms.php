<?php
function smarty_function_cms(&$params, &$smarty)
{
	if(empty($params['func'])) exit(new Error(509));
}
?>
