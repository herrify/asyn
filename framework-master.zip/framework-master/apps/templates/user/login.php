<html>

<body>
<form method="post">
    <label> 用户名：<input type="text" name="username"/></label>
    <label> 密码：<input type="password" name="password"/></label>
    <input type="submit"/>
</form>

</body>
</html>