<?php
/**
 * Introduction list:How to build Mutiple HTTP GET Request with sync
 * 
* @author iPHPJungle
* @since 2015/07/02 周四(Thursday)
*/