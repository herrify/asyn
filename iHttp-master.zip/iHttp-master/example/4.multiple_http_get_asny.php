<?php
/**
 * Introduction list:How to build Mutiple HTTP GET Request with asyn
 *
 * @author PHPJungle
 * @since 2015/07/03 周五
 */